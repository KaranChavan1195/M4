﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ModelDemo.Models;
namespace ModelDemo.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult DisplayEmployees()
        {
          //  EmployeeOperation empOp = new EmployeeOperation();

            ViewData["employees"] = EmployeeOperation.empList;

                return View();
         }

        public ActionResult SearchEmployee(int id) 
        {
         //   EmployeeOperation empOp = new EmployeeOperation();
            Employee emp = EmployeeOperation.empList.Find(e=> e.EmployeeID ==id);
            if (emp != null)
                return View(emp);
            else
                return Content("Employee Id Doesn't Exists");
        }
        //public ActionResult SeachbySalary(int sal)
        //{
        //    EmployeeOperation empOp = new EmployeeOperation();
        //    Employee emp = empOp.empList.Find(e => e.Salary > sal);
        //    if (emp != null)
        //        return View(empOp.empList);
        //    else Content("Salary Doesnt Match");
        //}
        public ActionResult SeachEmpByCity(String City) 
        {
      //  EmployeeOperation empOp = new EmployeeOperation();
        List<Employee> emps = new List<Employee>();
        foreach (var item in EmployeeOperation.empList)
        {
            if(item.City == City)
            {
                emps.Add(item);
            }
         
        }
        return View(emps);
        }

        public ActionResult Index() {
            return View();
        }
        public ActionResult CreatingEmployee() {
            return View();
        }
        [HttpPost]
        public ActionResult CreatingEmployee(Employee emp) 
        {
            if (ModelState.IsValid)
            {
               // EmployeeOperation empOp = new EmployeeOperation();
                EmployeeOperation.empList.Add(emp);
                return RedirectToAction("Index");
            }
            else
                return View(emp);
        }
        public ActionResult DeleteEmployee()
        {
            return View();
        }
          [HttpPost]
        public ActionResult DeleteEmployee(int id) 
        {
            Employee emp = new Employee();
            if (ModelState.IsValid)
            {
                emp = EmployeeOperation.empList.Find(e => e.EmployeeID == id);
                EmployeeOperation.empList.Remove(emp);
                return RedirectToAction("Index");
            }
            else
                return View(id);
        }
          public ActionResult UpdateEmployee()
          {

              return View();

          }

          [HttpPost]
          public ActionResult UpdateEmployee(Employee emps)
          {

              if (ModelState.IsValid)
              {
                  Employee emp = new Employee();
                  emp = EmployeeOperation.empList.First(e => e.EmployeeID == emps.EmployeeID);
                  emp.Name = emps.Name;
                  emp.Salary = emps.Salary;
                  emp.City = emps.City;

                  return RedirectToAction("index");
              }
              else
              {
                  return View();
              }

          } 
     }

}

