﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ModelDemo.Models
{
    public class EmployeeOperation
    {

        public static List<Employee> empList = new List<Employee>();

         static EmployeeOperation() 
        {
            empList.Add(new Employee() { EmployeeID = 101, Name="Karan",   City="Mumbai",       Salary = 500000 });
            empList.Add(new Employee() { EmployeeID = 102, Name = "Kunal", City = "Vidharbha",  Salary = 600000 });
            empList.Add(new Employee() { EmployeeID = 103, Name = "Akash", City = "Nashik",     Salary = 700000 });
            empList.Add(new Employee() { EmployeeID = 104, Name = "Sai",   City = "Thane",      Salary = 800000 });
            empList.Add(new Employee() { EmployeeID = 105, Name = "Chetan",City = "Alibaug",    Salary = 900000 });
            empList.Add(new Employee() { EmployeeID = 106, Name = "Sayali",City = "Dombivali",  Salary = 120000 });
            empList.Add(new Employee() { EmployeeID = 107, Name = "Shweta",City = "Nerul",      Salary = 122000 });
            empList.Add(new Employee() { EmployeeID = 108, Name = "bhakti",City = "Kalyan",     Salary = 560000 });
            empList.Add(new Employee() { EmployeeID = 109, Name = "Linet", City = "Thane",      Salary = 570000 });
            empList.Add(new Employee() { EmployeeID = 110, Name = "Mayur", City = "Panvel",     Salary = 540000 });
            empList.Add(new Employee() { EmployeeID = 111, Name = "Gopal", City = "Boisar",     Salary = 510000 });
        }
    }
}