﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ModelDemobyModel.Models;
namespace ModelDemobyModel.Controllers
{
    public class EmployeeModelController : Controller
    {
        ModelEntities context = new ModelEntities();
        // GET: /EmployeeModel/
        
        public ActionResult Index()
        {
            return View();
            
        }
        //public ActionResult IndexOne() {
        //    EmployeeModel en = new EmployeeModel();
        //    return View( en.EmployeeModel);
        //}


        public ActionResult CreateEmployee() 
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateEmployee( EmployeeModel_121718 emp) 
        {

            if (ModelState.IsValid) 
            {
               context.EmployeeModel_121718.Add(emp);
                context.SaveChanges();
            }
            return View();
        }
      
        public ActionResult CrEmpScaffolding() {
            return View();
        }
 
        public ActionResult DisplayDetails() 
        {
            //return View();
            return View(context.EmployeeModel_121718);
        }
       
        
        
    }
}
