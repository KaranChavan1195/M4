﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ModelDemobyModel.Models;
namespace ModelDemobyModel.Controllers
{
    public class NewModelController : Controller
    {
        Training_18Jan2017_TalwadeEntities context = new Training_18Jan2017_TalwadeEntities();
        //
        // GET: /NewModel/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult CreateEmployee() 
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateEmployee(EmployeeMaster_121718 emp)
        {

            if (ModelState.IsValid)
            {
                context.EmployeeMaster_121718.Add(emp);
                context.SaveChanges();
            }
            return View();
        }
        public ActionResult DisplayDetails(int ID) 
        {
            return View(context.EmployeeMaster_121718.Find(ID));
        }

        public ActionResult UpdateEmployee(int ID)
        {

            return View(context.EmployeeMaster_121718.Find(ID));

        }

        [HttpPost]
        public ActionResult UpdateEmployee(EmployeeMaster_121718 emps)
        {

            if (ModelState.IsValid)
            {
                EmployeeMaster_121718 emp = new EmployeeMaster_121718();
                emp = context.EmployeeMaster_121718.First(e => e.ID == emps.ID);
                emp.Name = emps.Name;
                emp.Salary = emps.Salary;
                emp.Age = emps.Age;
                emp.Address = emps.Address;
                context.SaveChanges();

                return RedirectToAction("index");
            }
            else
            {
                return View();
            }

        }

    }
}
